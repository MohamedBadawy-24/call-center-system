const adminService = require('../services/adminService');

exports.listProfileRequests = async (req, res, next) => {
  try {
    const requests = await adminService.listProfileRequests();
    res.json(requests);
  } catch (err) {
    next(err);
  }
};

exports.resolveProfileRequest = async (req, res, next) => {
  try {
    const { status, adminNote } = req.body;
    const io = req.app.get('io');
    await adminService.resolveProfileRequest(req.params.id, status, adminNote, io);
    res.json({ message: `Request successfully ${status}` });
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    next(err);
  }
};

exports.listUsers = async (req, res, next) => {
  try {
    const users = await adminService.listUsers();
    res.json(users);
  } catch (err) {
    next(err);
  }
};

exports.deleteUser = async (req, res, next) => {
  try {
    const targetId = req.params.id;
    const io = req.app.get('io');
    await adminService.deleteUser(targetId, req.user.id, io);
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    next(err);
  }
};

exports.updateResearcherCode = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { researcherCode } = req.body;
    const io = req.app.get('io');
    const user = await adminService.updateResearcherCode(id, researcherCode, io);
    res.json(user);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    next(err);
  }
};
